def my_func():
    print('Hello World')
