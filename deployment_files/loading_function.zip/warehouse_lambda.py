def warehouse_lambda_handler(event, context):
    pass
